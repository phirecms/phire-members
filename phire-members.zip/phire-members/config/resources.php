<?php

return [
    'members' => [
        'index',
        'add',
        'edit',
        'remove',
    ],
    'member-login'       => [],
    'member-register'    => [],
    'member-forgot'      => [],
    'member-profile'     => [],
    'member-unsubscribe' => []
];